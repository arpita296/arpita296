AI Timetable Scheduler — Offline PHP (Black & Gold Theme)
------------------------------------------------------------
How to run:
1. Install XAMPP and start Apache (run as admin if needed).
2. Extract this folder into XAMPP's htdocs directory, e.g.:
   C:\xampp\htdocs\AI-Timetable-P2-BlackGold
3. Open in browser:
   http://localhost/AI-Timetable-P2-BlackGold/  (or include port if changed, e.g. :8080)
4. Use the UI: click Load Demo, then Generate Timetable. Save / Download CSV as needed.

Notes:
- Offline PHP generator distributes subjects equally across Mon–Sat with 7 periods/day (T1 style).
- Subjects preloaded: Mathematics, Digital Electronics, Analog Electronics, DSA, Humanities.
- No external APIs required.
