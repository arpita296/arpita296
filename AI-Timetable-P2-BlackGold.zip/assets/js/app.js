// frontend JS for Black & Gold PHP offline timetable (Mon-Sat x 7 periods)
const subName = document.getElementById('subName');
const subTeacher = document.getElementById('subTeacher');
const subPeriods = document.getElementById('subPeriods');
const addSub = document.getElementById('addSub');
const subjectsDiv = document.getElementById('subjects');
const availabilityDiv = document.getElementById('availability');
const generateBtn = document.getElementById('generate');
const loadDemo = document.getElementById('loadDemo');
const downloadBtn = document.getElementById('download');
const saveBtn = document.getElementById('save');
const status = document.getElementById('status');
const timetableDiv = document.getElementById('timetable');

let subjects = [];
let availability = {}; // teacher -> day -> period -> bool
let lastTimetable = null;

function uid(prefix='s'){ return prefix + '_' + Math.random().toString(36).slice(2,9); }
function saveLocal(){ localStorage.setItem('ai_tt_blackgold', JSON.stringify({subjects, availability})); }
function loadLocal(){ const raw = localStorage.getItem('ai_tt_blackgold'); if (raw){ const d = JSON.parse(raw); subjects = d.subjects || []; availability = d.availability || {}; } }

function renderSubjects(){
  subjectsDiv.innerHTML = '';
  if (!subjects.length) subjectsDiv.innerHTML = '<div class="status">No subjects yet</div>';
  subjects.forEach(s=>{
    const el = document.createElement('div'); el.className='subject-row';
    el.innerHTML = `<div><strong>${s.name}</strong> <div style="color:rgba(255,255,255,0.7)">${s.teacher}</div></div>
      <div><span style="margin-right:8px">${s.periodsPerWeek}pw</span><button onclick="editSub('${s.id}')" class="btn ghost">Edit</button> <button onclick="delSub('${s.id}')" class="btn ghost">Del</button></div>`;
    subjectsDiv.appendChild(el);
  });
}

function editSub(id){
  const s = subjects.find(x=>x.id===id); if (!s) return;
  const n = prompt('Subject name', s.name); if (!n) return;
  const t = prompt('Teacher', s.teacher) || s.teacher;
  const p = Number(prompt('Periods/week', s.periodsPerWeek) || s.periodsPerWeek);
  s.name = n; s.teacher = t; s.periodsPerWeek = p;
  cleanupTeachers(); renderSubjects(); renderAvailability(); saveLocal();
}

function delSub(id){ if (!confirm('Delete subject?')) return; subjects = subjects.filter(x=>x.id!==id); cleanupTeachers(); renderSubjects(); renderAvailability(); saveLocal(); }

addSub.addEventListener('click', ()=>{
  const name = subName.value.trim(); const teacher = subTeacher.value.trim(); const periods = Number(subPeriods.value) || 0;
  if (!name || !teacher || !periods){ alert('Enter subject, teacher, periods'); return; }
  subjects.push({ id: uid('sub'), name, teacher, periodsPerWeek: periods });
  subName.value=''; subTeacher.value=''; subPeriods.value='4';
  cleanupTeachers(); renderSubjects(); renderAvailability(); saveLocal();
});

function cleanupTeachers(){
  const teachers = Array.from(new Set(subjects.map(s=>s.teacher)));
  Object.keys(availability).forEach(t=>{ if (!teachers.includes(t)) delete availability[t]; });
  teachers.forEach(t=>{ if (!availability[t]){ availability[t] = {}; for (let d=0; d<6; d++){ availability[t][d] = {}; for (let p=0;p<7;p++) availability[t][d][p] = true; } } });
}

function renderAvailability(){
  availabilityDiv.innerHTML = '';
  const teachers = Object.keys(availability);
  if (!teachers.length){ availabilityDiv.innerHTML = '<div class="status">Add subjects to edit availability</div>'; return; }
  teachers.forEach(t=>{
    const box = document.createElement('div'); box.className='avail-row';
    const label = document.createElement('div'); label.style.minWidth='120px'; label.style.fontWeight='700'; label.textContent = t;
    box.appendChild(label);
    for (let p=0; p<7; p++){
      const sl = document.createElement('div'); sl.className='slot'; sl.textContent = 'P' + (p+1);
      if (!availability[t][0][p]) sl.classList.add('unavail');
      sl.addEventListener('click', ()=>{ const newVal = !availability[t][0][p]; for (let d=0; d<6; d++) availability[t][d][p] = newVal; renderAvailability(); saveLocal(); });
      box.appendChild(sl);
    }
    availabilityDiv.appendChild(box);
  });
}

loadDemo.addEventListener('click', ()=> {
  subjects = [
    { id: uid('sub'), name: 'Mathematics', teacher: 'Dr. Mehta', periodsPerWeek: 7 },
    { id: uid('sub'), name: 'Digital Electronics', teacher: 'Prof. Sharma', periodsPerWeek: 6 },
    { id: uid('sub'), name: 'Analog Electronics', teacher: 'Prof. Roy', periodsPerWeek: 5 },
    { id: uid('sub'), name: 'DSA', teacher: 'Ms. Rao', periodsPerWeek: 6 },
    { id: uid('sub'), name: 'Humanities', teacher: 'Mr. Sen', periodsPerWeek: 3 }
  ];
  cleanupTeachers(); renderSubjects(); renderAvailability(); saveLocal(); status.textContent = 'Demo loaded';
});

generateBtn.addEventListener('click', async ()=>{
  if (!subjects.length){ alert('Add subjects first'); return; }
  status.textContent = 'Generating timetable...';
  const payload = { subjects, availability };
  try {
    const res = await fetch('api/generate.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json();
    if (!res.ok){ status.textContent = 'Server error'; console.error(data); return; }
    lastTimetable = data.timetable;
    renderServerTimetable(lastTimetable);
    status.textContent = 'Timetable generated';
  } catch (err) {
    status.textContent = 'Network error: ' + err.message;
  }
});

function renderServerTimetable(timetable){
  if (!timetable || !Array.isArray(timetable)){ timetableDiv.innerHTML = '<div class="status">Invalid timetable returned</div>'; return; }
  const table = document.createElement('table'); table.className='table';
  const thead = document.createElement('thead'); const trh = document.createElement('tr');
  trh.innerHTML = '<th>Day</th>' + Array.from({length:7}).map((_,i)=>`<th>P${i+1}</th>`).join('');
  thead.appendChild(trh); table.appendChild(thead);
  const tbody = document.createElement('tbody');
  timetable.forEach(row=>{
    const tr = document.createElement('tr'); const th = document.createElement('th'); th.textContent = row.day; tr.appendChild(th);
    row.slots.forEach(s=>{
      const td = document.createElement('td');
      if (!s) td.innerHTML = '<div class="status">—</div>';
      else td.innerHTML = `<div class="cell-sub">${s.subject}</div><div class="cell-teacher">${s.teacher}</div>`;
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody); timetableDiv.innerHTML = ''; timetableDiv.appendChild(table);
}

saveBtn.addEventListener('click', async ()=>{
  if (!lastTimetable) return alert('Generate timetable first');
  const name = prompt('Save name', 'timetable1');
  if (!name) return;
  try {
    const res = await fetch('api/save.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name, timetable:lastTimetable}) });
    const j = await res.json();
    if (res.ok) alert('Saved: ' + j.path);
    else alert('Save error: ' + (j.error || 'unknown'));
  } catch (err) { alert('Error: ' + err.message); }
});

downloadBtn.addEventListener('click', ()=>{
  if (!lastTimetable) return alert('Generate timetable first');
  const rows = [];
  rows.push(['Day','P1','P2','P3','P4','P5','P6','P7'].join(','));
  lastTimetable.forEach(r=>{
    const row = [r.day];
    r.slots.forEach(s => row.push(s ? `"${s.subject} (${s.teacher})"` : ''));
    rows.push(row.join(','));
  });
  const csv = rows.join('\n'); const blob = new Blob([csv], {type:'text/csv'}); const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'timetable.csv'; a.click(); URL.revokeObjectURL(url);
});

// init
loadLocal(); cleanupTeachers(); renderSubjects(); renderAvailability();
