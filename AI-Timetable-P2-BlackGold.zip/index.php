<?php
// index.php - Black & Gold Theme Frontend
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>AI Timetable Scheduler — Black & Gold</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <div class="container">
    <header class="topbar">
      <div class="brand">
        <div class="logo">AI</div>
        <div>
          <h1>AI Timetable Scheduler</h1>
          <small class="muted">Offline PHP • Equal-distribution Timetable (Mon–Sat × 7 periods) • Black & Gold</small>
        </div>
      </div>
      <div class="actions">
        <button id="loadDemo" class="btn ghost">Load Demo</button>
      </div>
    </header>

    <main class="grid">
      <section class="panel left">
        <h2>Subjects & Teachers</h2>

        <div class="form-row">
          <input id="subName" placeholder="Subject (e.g. Mathematics)" />
          <input id="subTeacher" placeholder="Teacher (e.g. Dr. Mehta)" />
          <input id="subPeriods" type="number" min="1" max="21" value="4" />
          <button id="addSub" class="btn">Add</button>
        </div>

        <div id="subjects" class="list"></div>

        <h3>Teacher availability (quick toggle)</h3>
        <div id="availability" class="availability"></div>

        <div style="margin-top:12px;">
          <button id="generate" class="btn primary">Generate Timetable (Server AI)</button>
          <button id="download" class="btn ghost">Download CSV</button>
          <button id="save" class="btn ghost">Save Timetable</button>
        </div>

        <div id="status" class="status muted"></div>
      </section>

      <section class="panel right">
        <h2>Generated Timetable (Mon–Sat × P1–P7)</h2>
        <div id="timetable" class="timetable"></div>
      </section>
    </main>

    <footer class="footer">Local Offline AI • No network required • Black & Gold</footer>
  </div>

  <script src="assets/js/app.js"></script>
</body>
</html>
