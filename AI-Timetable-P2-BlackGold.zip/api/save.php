<?php
header('Content-Type: application/json');
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data || !isset($data['name']) || !isset($data['timetable'])) { http_response_code(400); echo json_encode(['error'=>'Invalid payload']); exit; }
$name = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $data['name']);
$dir = __DIR__ . '/../data';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$filename = $dir . '/' . $name . '.json';
file_put_contents($filename, json_encode($data['timetable'], JSON_PRETTY_PRINT));
echo json_encode(['ok'=>true,'path'=>'data/'.basename($filename)]);
?>
