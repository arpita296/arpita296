<?php
// generate.php - Equal-distribution timetable generator (T1: distribute subjects equally across Mon-Sat, 7 periods)
header('Content-Type: application/json');

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) {
    http_response_code(400);
    echo json_encode(['error'=>'Invalid JSON payload']);
    exit;
}
$subjects = $data['subjects'] ?? [];
// normalize subjects and ensure ids
foreach ($subjects as &$s) {
    if (!isset($s['id']) || !$s['id']) $s['id'] = uniqid('sub_');
    $s['periodsPerWeek'] = isset($s['periodsPerWeek']) ? intval($s['periodsPerWeek']) : 0;
}
unset($s);

$DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat'];
$PERIODS = ['P1','P2','P3','P4','P5','P6','P7'];
$ND = count($DAYS);
$NP = count($PERIODS);
$TOTAL_SLOTS = $ND * $NP;

// If no subjects provided, load defaults
if (empty($subjects)) {
    $subjects = [
        ['id'=>uniqid('sub_'), 'name'=>'Mathematics', 'teacher'=>'Dr. Mehta', 'periodsPerWeek'=>7],
        ['id'=>uniqid('sub_'), 'name'=>'Digital Electronics', 'teacher'=>'Prof. Sharma', 'periodsPerWeek'=>6],
        ['id'=>uniqid('sub_'), 'name'=>'Analog Electronics', 'teacher'=>'Prof. Roy', 'periodsPerWeek'=>5],
        ['id'=>uniqid('sub_'), 'name'=>'DSA', 'teacher'=>'Ms. Rao', 'periodsPerWeek'=>6],
        ['id'=>uniqid('sub_'), 'name'=>'Humanities', 'teacher'=>'Mr. Sen', 'periodsPerWeek'=>3]
    ];
}

// Build a flat pool by repeating subjects proportional to periodsPerWeek,
// but for T1 we will override to distribute equally: compute target slots per subject = floor(TOTAL_SLOTS / n)
$n = count($subjects);
$target = intdiv($TOTAL_SLOTS, max(1,$n)); // base count per subject
$pool = [];
foreach ($subjects as $s) {
    $count = $target;
    for ($i=0;$i<$count;$i++) $pool[] = $s['id'];
}
// If there are remaining slots, fill with subjects in round-robin
$remaining = $TOTAL_SLOTS - count($pool);
$idx = 0;
while ($remaining > 0) {
    $pool[] = $subjects[$idx % $n]['id'];
    $idx++; $remaining--;
}

// Now assign pool entries to timetable across days and periods, avoiding same subject twice in same day when possible
shuffle($pool);
$timetable = array_fill(0, $ND, array_fill(0, $NP, null));
$pos = 0;
for ($d=0;$d<$ND;$d++) {
    for ($p=0;$p<$NP;$p++) {
        if ($pos >= count($pool)) break;
        // ensure not repeating subject in same day: try to find next pool item that isn't in same day
        $placed = false;
        for ($look=0;$look<min(6,count($pool));$look++) {
            $candidate = $pool[$pos];
            // check if candidate already exists in this day
            $exists = false;
            for ($pp=0;$pp<$NP;$pp++) {
                if ($timetable[$d][$pp] && $timetable[$d][$pp]['subjectId'] === $candidate) { $exists = true; break; }
            }
            if (!$exists) {
                // find subject details
                foreach ($subjects as $s) {
                    if ($s['id'] === $candidate) {
                        $timetable[$d][$p] = ['subjectId'=>$s['id'],'subjectName'=>$s['name'],'teacher'=>$s['teacher']];
                        break;
                    }
                }
                array_splice($pool, $pos, 1);
                $placed = true;
                break;
            } else {
                $pos = ($pos + 1) % count($pool);
            }
        }
        if (!$placed) {
            // place whatever is next
            if (count($pool)>0) {
                $candidate = array_shift($pool);
                foreach ($subjects as $s) {
                    if ($s['id'] === $candidate) {
                        $timetable[$d][$p] = ['subjectId'=>$s['id'],'subjectName'=>$s['name'],'teacher'=>$s['teacher']];
                        break;
                    }
                }
            }
        }
    }
}

// prepare output
$out = [];
for ($d=0;$d<$ND;$d++){
    $row = ['day'=>$DAYS[$d], 'slots'=>[]];
    for ($p=0;$p<$NP;$p++){
        if ($timetable[$d][$p]) $row['slots'][] = ['subject'=>$timetable[$d][$p]['subjectName'],'teacher'=>$timetable[$d][$p]['teacher']];
        else $row['slots'][] = null;
    }
    $out[] = $row;
}
echo json_encode(['timetable'=>$out]);
?>
